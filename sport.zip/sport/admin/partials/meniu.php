<html>

<head>
     <title>Aplicatie pentru evidenta atletilor - Home Page</title>
     
     <link rel="stylesheet" href="../css/admin.css">

</head>


<body>
    <?php include ('config.php'); ?> <!-- e inclusa baza de date aici -->
   <!-- Menu Section Starts -->
    <div class="menu text-center">
       <div class="wrapper">
           <ul>
               <li><a href="index.php">Home</a></li>
               <li><a href="atleti.php">Atleti</a></li>
               <li><a href="antrenori.php">Antrenori</a></li>
               <li><a href="sponsori_principali.php">Sponsori principali</a></li>
               <li><a href="competitii.php">Competitii</a></li>
               <li><a href="probe.php">Probe</a></li>
               <li><a href="competitii_frecventate.php">Competitii frecventate</a></li>
               <li><a href="sustinere_probe.php">Sustinere probe</a></li>
               <li><a href="interogari_simple.php">Relatii<br></a></li>

           </ul>
      </div>
    </div>

    
   <!-- Menu Section Ends -->